
const Doctor = require("../models/doctorModel");

const getRecommendations = async (req, res) => {
  try {
    const userId = req.user.id;
    
    if (!userId) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const { specialization, experience, limit = 10 } = req.query;

    const query = {
      isDoctor: true, 
    };

    if (specialization) {
      query.specialization = specialization;
    }

    if (experience) {
      query.experience = { $gte: parseInt(experience) };
    }

    const recommendations = await Doctor.find(query)
      .sort({ rating: -1, experience: -1 }) 
      .limit(parseInt(limit))
      .select('firstname lastname specialization experience rating about'); 

    return res.json(recommendations);
  } catch (error) {
    console.error("Error fetching recommendations:", error);
    return res.status(500).json({ 
      message: "Unable to fetch recommendations",
      error: error.message 
    });
  }
};

module.exports = { getRecommendations };