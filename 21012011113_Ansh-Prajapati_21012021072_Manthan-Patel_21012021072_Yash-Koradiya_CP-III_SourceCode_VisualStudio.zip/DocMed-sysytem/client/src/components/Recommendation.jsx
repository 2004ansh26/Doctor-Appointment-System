import React, { useEffect, useState } from 'react';
import Footer from "../components/Footer";
import Navbar from "../components/Navbar";
import "../styles/contact.css";

const Recommendation = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [doctorTypes, setDoctorTypes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedType, setSelectedType] = useState('');
  const [selectedExperience, setSelectedExperience] = useState('');
  const [selectedFees, setSelectedFees] = useState('');

  const token = localStorage.getItem('token');
  const isAuthenticated = Boolean(token);

  // Fetch doctor types
  useEffect(() => {
    const fetchDoctorTypes = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/doctor/types', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          }
        });

        if (!response.ok) {
          throw new Error('Failed to fetch doctor types');
        }

        const data = await response.json();
        setDoctorTypes(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error('Error fetching doctor types:', err);
        setError('Failed to load doctor types');
      }
    };

    if (isAuthenticated) {
      fetchDoctorTypes();
    }
  }, [isAuthenticated, token]);

  // Fetch recommendations
  useEffect(() => {
    const fetchRecommendations = async () => {
      if (!isAuthenticated) return;
      
      setLoading(true);
      setError(null);

      try {
        let url = 'http://localhost:5000/api/doctor/recommendations?';
        const params = new URLSearchParams();
        
        if (selectedType) params.append('specialization', selectedType);
        if (selectedExperience) params.append('experience', selectedExperience);
        if (selectedFees) params.append('fees', selectedFees);
        
        url += params.toString();

        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          }
        });

        if (!response.ok) {
          throw new Error('Failed to fetch recommendations');
        }

        const data = await response.json();
        setRecommendations(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error('Error fetching recommendations:', err);
        setError('Failed to load recommendations');
      } finally {
        setLoading(false);
      }
    };

    fetchRecommendations();
  }, [isAuthenticated, token, selectedType, selectedExperience, selectedFees]);

  if (!isAuthenticated) {
    return <div className="p-4 text-center">Please log in to view recommendations</div>;
  }

  return (
    <>
      <Navbar />
      <div className="container mx-auto p-4">
        <h2 className="text-2xl font-bold mb-4">Find a Doctor</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <label className="block mb-2">Doctor Type:</label>
            <select 
              className="w-full p-2 border rounded"
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
            >
              <option value="">Select Type</option>
              {doctorTypes.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block mb-2">Minimum Experience (years):</label>
            <input
              type="number"
              className="form-input w-full p-2 border rounded"
              value={selectedExperience}
              onChange={(e) => setSelectedExperience(e.target.value)}
              min="0"
            />
          </div>

          <div>
            <label className="block mb-2">Maximum Fees:</label>
            <input
              type="number"
              className="form-input w-full p-2 border rounded"
              value={selectedFees}
              onChange={(e) => setSelectedFees(e.target.value)}
              min="0"
            />
          </div>
        </div>

        {loading && <div className="text-center">Loading...</div>}
        {error && <div className="text-red-500 text-center">{error}</div>}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {recommendations.length > 0 ? (
            recommendations.map((doctor) => (
              <div key={doctor._id} className="border rounded p-4 shadow">
                <h4 className="font-bold text-lg">Dr. {doctor.userId?.firstname || 'Unknown'} {doctor.userId?.lastname || ''}</h4>
                <p>Specialization: {doctor.specialization}</p>
                <p>Experience: {doctor.experience} years</p>
                <p>Fees: ${doctor.fees}</p>
              </div>
            ))
          ) : (
            <div className="col-span-full text-center">No recommendations available</div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Recommendation;