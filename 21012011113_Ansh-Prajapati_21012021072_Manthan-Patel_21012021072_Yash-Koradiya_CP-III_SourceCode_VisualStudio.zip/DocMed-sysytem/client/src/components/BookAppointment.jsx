import React, { useState } from "react";
import "../styles/bookappointment.css";
import axios from "axios";
import toast from "react-hot-toast";
import { IoMdClose } from "react-icons/io";
import moment from "moment";

const BookAppointment = ({ setModalOpen, ele }) => {
  const [formDetails, setFormDetails] = useState({
    date: "",
    time: "",
  });

  const inputChange = (e) => {
    const { name, value } = e.target;
    return setFormDetails({
      ...formDetails,
      [name]: value,
    });
  };

  // const bookAppointment = async (e) => {
  //   e.preventDefault();
  //   try {
  //     await toast.promise(
  //       axios.post(
  //         "/appointment/bookappointment",
  //         {
  //           doctorId: ele?.userId?._id,
  //           date: formDetails.date,
  //           time: formDetails.time,
  //           doctorname: `${ele?.userId?.firstname} ${ele?.userId?.lastname}`,
  //         },
  //         {
  //           headers: {
  //             Authorization: `Bearer ${localStorage.getItem("token")}`,
  //           },
  //         }
  //       ),
  //       {
  //         success: "Appointment booked successfully",
  //         error: "Unable to book appointment",
  //         loading: "Booking appointment...",
  //       }
  //     );
  //     setModalOpen(false);
  //   } catch (error) {
  //     return error;
  //   }
  // };
  const bookAppointment = async (e) => {
    e.preventDefault();

    const { date, time } = formDetails;
    
    // Get current date and time in local timezone
    const currentDateTime = moment();

    // Create a moment object for the selected appointment date and time
    const appointmentDateTime = moment(`${date} ${time}`, 'YYYY-MM-DD HH:mm');

    // Validate the appointment date and time
    if (!appointmentDateTime.isValid()) {
      return toast.error("Invalid date or time format");
    }

    if (appointmentDateTime.isBefore(currentDateTime)) {
      return toast.error("You cannot book an appointment for a past date and time");
    }

    try {
      await toast.promise(
        axios.post(
          "/appointment/bookappointment",
          {
            doctorId: ele?.userId?._id,
            date: date,
            time: time,
            doctorname: `${ele?.userId?.firstname} ${ele?.userId?.lastname}`,
          },
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        ),
        {
          success: "Appointment booked successfully",
          error: "Unable to book appointment",
          loading: "Booking appointment...",
        }
      );
      setModalOpen(false);
    } catch (error) {
      console.error("Booking appointment error:", error.response?.data?.message || error.message);
      toast.error(error.response?.data?.message || "Unable to book appointment");
    }
  };
  
  return (
    <>
      <div className="modal flex-center">
        <div className="modal__content">
          <h2 className="page-heading">Book Appointment</h2>
          <IoMdClose
            onClick={() => {
              setModalOpen(false);
            }}
            className="close-btn"
          />
          <div className="register-container flex-center book">
            <form className="register-form">
              <input
                type="date"
                name="date"
                className="form-input"
                value={formDetails.date}
                onChange={inputChange}
                min={moment().format("YYYY-MM-DD")}
              />
              <input
                type="time"
                name="time"
                className="form-input"
                value={formDetails.time}
                onChange={inputChange}
                min="00:00"
                max="23:59"
              />
              <button
                type="submit"
                className="btn form-btn"
                onClick={bookAppointment}
              >
                book
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookAppointment;
